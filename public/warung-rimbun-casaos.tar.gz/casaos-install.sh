#!/usr/bin/env bash
# ==============================================================================
# WARUNG RIMBUN - Otomatisasi Instalasi & Manajemen CasaOS / Docker
# Wadah Urun Rembuk Perencanaan dan Inovasi Pembangunan
# Domain Publik : https://warungrimbun.cloudpme.my.id
# Tunnel ID     : 4b630e38-406c-4895-a80e-1fabea7a3b1b
# ==============================================================================

set -e

# Warna Terminal
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Direktori proyek saat ini
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Parameter Default Terkonfigurasi Otomatis
DEFAULT_PORT=8880
DEFAULT_TUNNEL_ID="4b630e38-406c-4895-a80e-1fabea7a3b1b"
DEFAULT_HOSTNAME="warungrimbun.cloudpme.my.id"

print_header() {
  clear 2>/dev/null || true
  echo -e "${CYAN}${BOLD}"
  echo "======================================================================"
  echo "   WARUNG RIMBUN - INSTALLER & PENGATURAN OTOMATIS CASAOS / DOCKER    "
  echo "      Wadah Urun Rembuk Perencanaan dan Inovasi Pembangunan           "
  echo "   Domain  : https://${DEFAULT_HOSTNAME}                              "
  echo "   Tunnel  : ${DEFAULT_TUNNEL_ID}                                     "
  echo "======================================================================"
  echo -e "${NC}"
}

check_dependencies() {
  echo -e "${BLUE}▶ Memeriksa dependensi sistem...${NC}"
  
  if ! command -v docker &> /dev/null; then
    echo -e "${RED}✘ Docker belum terpasang di sistem ini.${NC}"
    echo -e "Silakan pasang Docker terlebih dahulu dengan perintah:"
    echo -e "${YELLOW}  curl -fsSL https://get.docker.com | sh${NC}"
    exit 1
  fi
  echo -e "${GREEN}✔ Docker terdeteksi: $(docker --version | head -n 1)${NC}"

  # Cek docker compose (v2) atau docker-compose (v1)
  if docker compose version &> /dev/null; then
    COMPOSE_CMD="docker compose"
  elif command -v docker-compose &> /dev/null; then
    COMPOSE_CMD="docker-compose"
  else
    echo -e "${RED}✘ Docker Compose belum terpasang.${NC}"
    echo -e "Pasang docker compose plugin atau gunakan perintah:"
    echo -e "${YELLOW}  sudo apt-get install docker-compose-plugin${NC}"
    exit 1
  fi
  echo -e "${GREEN}✔ Docker Compose terdeteksi: $($COMPOSE_CMD version | head -n 1)${NC}"
  echo ""
}

get_local_ip() {
  LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
  if [ -z "$LOCAL_IP" ]; then
    LOCAL_IP="localhost"
  fi
  echo "$LOCAL_IP"
}

action_install() {
  print_header
  check_dependencies

  USER_PORT=${PORT:-$DEFAULT_PORT}
  TUNNEL_ID=${CLOUDFLARE_TUNNEL_ID:-$DEFAULT_TUNNEL_ID}
  HOSTNAME=${CLOUDFLARE_HOSTNAME:-$DEFAULT_HOSTNAME}

  echo -e "${CYAN}${BOLD}--- MENJALANKAN SETUP OTOMATIS TANPA PERLU KONFIGURASI MANUAL ---${NC}"
  echo -e "• Port Lokal     : ${YELLOW}${USER_PORT}${NC}"
  echo -e "• Domain Publik  : ${GREEN}https://${HOSTNAME}${NC}"
  echo -e "• Cloudflare ID  : ${CYAN}${TUNNEL_ID}${NC}"
  echo ""

  # Periksa parameter token dari argumen atau file .env
  if [ -n "$TOKEN_ARG" ]; then
    CF_TOKEN="$TOKEN_ARG"
  elif [ -f .env ] && grep -q "CLOUDFLARE_TUNNEL_TOKEN=" .env; then
    CF_TOKEN=$(grep "CLOUDFLARE_TUNNEL_TOKEN=" .env | cut -d '=' -f2- | tr -d '"' | tr -d "'")
  else
    CF_TOKEN=""
  fi

  # Simpan ke .env jika belum ada
  cat <<EOF > .env
CLOUDFLARE_TUNNEL_ID=${TUNNEL_ID}
CLOUDFLARE_HOSTNAME=${HOSTNAME}
CLOUDFLARE_TUNNEL_TOKEN=${CF_TOKEN}
PORT=${USER_PORT}
EOF

  echo -e "${GREEN}✔ Konfigurasi otomatis tersimpan di .env${NC}"
  echo ""
  echo -e "${BLUE}▶ Membangun image Docker & mengaktifkan WARUNG RIMBUN + Cloudflare Tunnel...${NC}"
  echo "Tunggu beberapa saat untuk proses kompilasi awal..."
  echo ""

  $COMPOSE_CMD -f docker-compose.yml up -d --build

  SERVER_IP=$(get_local_ip)

  echo ""
  echo -e "${GREEN}${BOLD}======================================================================"
  echo "   SELAMAT! WARUNG RIMBUN & CLOUDFLARE TUNNEL BERHASIL DIAKTIFKAN!   "
  echo "======================================================================${NC}"
  echo ""
  echo -e "Akses Publik (Internet Resmi via Cloudflare):"
  echo -e "  🌐 ${GREEN}${BOLD}https://${HOSTNAME}${NC}"
  echo ""
  echo -e "Akses Lokal Server / CasaOS:"
  echo -e "  👉 ${CYAN}${BOLD}http://${SERVER_IP}:${USER_PORT}${NC}"
  echo -e "  👉 ${CYAN}${BOLD}http://localhost:${USER_PORT}${NC}"
  echo ""
  echo -e "Informasi Tunnel:"
  echo -e "  • Tunnel ID : ${YELLOW}${TUNNEL_ID}${NC}"
  echo -e "  • Target    : ${CYAN}http://warung-rimbun:80${NC} (Otomatis terhubung via Docker)"
  echo ""
  echo -e "Perintah cepat:"
  echo -e "  • Cek status  : ${YELLOW}./setup.sh status${NC}"
  echo -e "  • Lihat log   : ${YELLOW}./setup.sh logs${NC}"
  echo -e "  • Restart     : ${YELLOW}./setup.sh restart${NC}"
  echo -e "  • Hentikan    : ${YELLOW}./setup.sh stop${NC}"
  echo "======================================================================"
}

action_status() {
  print_header
  check_dependencies
  echo -e "${BLUE}▶ Status Layanan WARUNG RIMBUN & Cloudflare Tunnel:${NC}"
  $COMPOSE_CMD -f docker-compose.yml ps
  echo ""
  SERVER_IP=$(get_local_ip)
  echo -e "Alamat Lokal  : ${CYAN}http://${SERVER_IP}:${DEFAULT_PORT}${NC}"
  echo -e "Alamat Publik : ${GREEN}https://${DEFAULT_HOSTNAME}${NC}"
}

action_logs() {
  check_dependencies
  echo -e "${BLUE}▶ Menampilkan live log container (Tekan Ctrl+C untuk keluar)...${NC}"
  $COMPOSE_CMD -f docker-compose.yml logs -f --tail=100
}

action_stop() {
  check_dependencies
  echo -e "${YELLOW}▶ Menghentikan container WARUNG RIMBUN & Tunnel...${NC}"
  $COMPOSE_CMD -f docker-compose.yml down
  echo -e "${GREEN}✔ Container berhasil dihentikan.${NC}"
}

action_start() {
  check_dependencies
  echo -e "${BLUE}▶ Menjalankan container WARUNG RIMBUN & Tunnel...${NC}"
  $COMPOSE_CMD -f docker-compose.yml up -d
  echo -e "${GREEN}✔ Container aktif.${NC}"
  action_status
}

action_restart() {
  check_dependencies
  echo -e "${BLUE}▶ Me-restart container WARUNG RIMBUN & Tunnel...${NC}"
  $COMPOSE_CMD -f docker-compose.yml restart
  echo -e "${GREEN}✔ Layanan berhasil di-restart.${NC}"
}

# Parse Argumen
TOKEN_ARG=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --token)
      TOKEN_ARG="$2"
      shift 2
      ;;
    status)
      action_status
      exit 0
      ;;
    logs)
      action_logs
      exit 0
      ;;
    stop)
      action_stop
      exit 0
      ;;
    start)
      action_start
      exit 0
      ;;
    restart)
      action_restart
      exit 0
      ;;
    auto|install|setup|"")
      action_install
      exit 0
      ;;
    *)
      echo -e "${RED}Perintah tidak dikenal: $1${NC}"
      echo "Penggunaan: ./setup.sh [install|start|stop|restart|status|logs] [--token <CF_TOKEN>]"
      exit 1
      ;;
  esac
done

action_install
