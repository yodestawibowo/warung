import { AspirasiPublik, KemitraanCSR, RisetAkademisi, InisiatifOMS, BabRPJMD, KonsultasiAgenda, MisiRPJMD, UserAccount, KonfirmasiKehadiranSidang, UnitKerjaOPD, MisiRPJMDItem } from '../types';

export const KECAMATAN_TANGGAMUS = [
  'Kecamatan Kota Agung',
  'Kecamatan Kota Agung Barat',
  'Kecamatan Kota Agung Timur',
  'Kecamatan Talang Padang',
  'Kecamatan Gisting',
  'Kecamatan Pulau Panggung',
  'Kecamatan Air Naningan',
  'Kecamatan Ulu Belu',
  'Kecamatan Sumberejo',
  'Kecamatan Pugung',
  'Kecamatan Gunung Alip',
  'Kecamatan Wonosobo',
  'Kecamatan Semaka',
  'Kecamatan Bandar Negeri Semuong',
  'Kecamatan Pematang Sawa',
  'Kecamatan Cukuh Balak',
  'Kecamatan Kelumbayan',
  'Kecamatan Kelumbayan Barat',
  'Kecamatan Limau',
  'Kecamatan Bulok',
  'Lintas Wilayah / Seluruh Daerah Tanggamus'
] as const;

export type KecamatanTanggamus = typeof KECAMATAN_TANGGAMUS[number];

export const PEKON_TANGGAMUS_MAP: Record<string, string[]> = {
  'Kecamatan Kota Agung': [
    'Kelurahan Kuripan', 'Kelurahan Pasar Madang', 'Kelurahan Baros', 'Kelurahan Kuta Dalom',
    'Pekon Terbaya', 'Pekon Teratas', 'Pekon Kota Agung', 'Pekon Campang Tiga',
    'Pekon Kelapa Nur', 'Pekon Kota Batu', 'Pekon Penanggungan', 'Pekon Benteng Jaya',
    'Pekon Terdana', 'Pekon Kandang Besi', 'Pekon Kedamaian', 'Pekon Pardasuka'
  ],
  'Kecamatan Kota Agung Barat': [
    'Pekon Payung', 'Pekon Kanyangan', 'Pekon Belu', 'Pekon Kalimiring',
    'Pekon Rajabasa', 'Pekon Negara Batin', 'Pekon Maja', 'Pekon Taba',
    'Pekon Sedayu', 'Pekon Kesugihan', 'Pekon Gedung Jambu'
  ],
  'Kecamatan Kota Agung Timur': [
    'Pekon Umbul Buah', 'Pekon Menggala', 'Pekon Sukabanjar', 'Pekon Teba',
    'Pekon Kagungan', 'Pekon Tanjung Anom', 'Pekon Batu Keramat', 'Pekon Kampung Baru',
    'Pekon Talang Rejo', 'Pekon Teba Lumbu', 'Pekon Karta'
  ],
  'Kecamatan Talang Padang': [
    'Pekon Talang Padang', 'Pekon Sukarame', 'Pekon Kalibening', 'Pekon Banding Agung',
    'Pekon Sinar Banten', 'Pekon Sinar Betung', 'Pekon Kejayan', 'Pekon Sinar Semendo',
    'Pekon Sukamaju', 'Pekon Way Halom', 'Pekon Singosari'
  ],
  'Kecamatan Gisting': [
    'Pekon Gisting Bawah', 'Pekon Gisting Atas', 'Pekon Landbaw', 'Pekon Campang',
    'Pekon Purwodadi', 'Pekon Sidokaton', 'Pekon Banjarmanis', 'Pekon Kuta Dalom',
    'Pekon Simpang Kanan'
  ],
  'Kecamatan Pulau Panggung': [
    'Pekon Pulau Panggung', 'Pekon Muara Dua', 'Pekon Tekad', 'Pekon Gunung Megang',
    'Pekon Way Jaha', 'Pekon Tanjung Begelung', 'Pekon Penantian', 'Pekon Gedung Cahya',
    'Pekon Batu Tegi', 'Pekon Sinar Mulyo'
  ],
  'Kecamatan Air Naningan': [
    'Pekon Air Naningan', 'Pekon Datar Lebuay', 'Pekon Karang Anyar', 'Pekon Way Harong',
    'Pekon Sinar Jawa', 'Pekon Air Kubang', 'Pekon Margomulyo', 'Pekon Batutegi Air Naningan'
  ],
  'Kecamatan Ulu Belu': [
    'Pekon Ngarip', 'Pekon Gunung Tiga', 'Pekon Air Abang', 'Pekon Pagar Alam',
    'Pekon Karang Rejo', 'Pekon Muara Dua Ulu Belu', 'Pekon Sirna Galih', 'Pekon Petai Kayu',
    'Pekon Datarajan'
  ],
  'Kecamatan Sumberejo': [
    'Pekon Sumberejo', 'Pekon Margodadi', 'Pekon Argopeni', 'Pekon Wonoharjo',
    'Pekon Dadapan', 'Pekon Tegal Binangun', 'Pekon Sidomulyo', 'Pekon Margoyoso'
  ],
  'Kecamatan Pugung': [
    'Pekon Rantau Tijang', 'Pekon Sukamaju', 'Pekon Tangkit Serdang', 'Pekon Babakan',
    'Pekon Tiuh Memon', 'Pekon Gunung Tiga', 'Pekon Way Jaha', 'Pekon Banjar Agung Udik'
  ],
  'Kecamatan Gunung Alip': [
    'Pekon Banjar Negeri', 'Pekon Suka Banjar', 'Pekon Pariaman', 'Pekon Kedaloman',
    'Pekon Sukamernah', 'Pekon Penanggungan', 'Pekon Darussalam'
  ],
  'Kecamatan Wonosobo': [
    'Pekon Sinar Rejeki', 'Pekon Padang Ratu', 'Pekon Balak', 'Pekon Soponyono',
    'Pekon Dadirejo', 'Pekon Kalisari', 'Pekon Karang Anyar', 'Pekon Bandar Kejadian'
  ],
  'Kecamatan Semaka': [
    'Pekon Sukaraja', 'Pekon Kanoman', 'Pekon Tugupapak', 'Pekon Sri Purnomo',
    'Pekon Bangun Rejo', 'Pekon Pardawaras', 'Pekon Margomulyo', 'Pekon Sedayu'
  ],
  'Kecamatan Bandar Negeri Semuong': [
    'Pekon Sanggi', 'Pekon Bandar Sukabumi', 'Pekon Negeri Ngarip', 'Pekon Simpang Kanan',
    'Pekon Atar Lebar', 'Pekon Gunung Dohar'
  ],
  'Kecamatan Pematang Sawa': [
    'Pekon Way Asahan', 'Pekon Betung', 'Pekon Teluk Brak', 'Pekon Kaur Gading',
    'Pekon Karang Brak', 'Pekon Pesanggrahan', 'Pekon Tampang Muda', 'Pekon Tirom'
  ],
  'Kecamatan Cukuh Balak': [
    'Pekon Putih Doh', 'Pekon Sukamaju', 'Pekon Kubulangka', 'Pekon Tanjung Betuah',
    'Pekon Pekondoh', 'Pekon Banjar Manis', 'Pekon Gedung Sukarame'
  ],
  'Kecamatan Kelumbayan': [
    'Pekon Kiluan Negeri', 'Pekon Paku', 'Pekon Penyandingan', 'Pekon Umbar',
    'Pekon Negeri', 'Pekon Napal'
  ],
  'Kecamatan Kelumbayan Barat': [
    'Pekon Batu Patah', 'Pekon Lengkukai', 'Pekon Merbau', 'Pekon Sidoharjo'
  ],
  'Kecamatan Limau': [
    'Pekon Kuripan', 'Pekon Badak', 'Pekon Antar Brak', 'Pekon Tegineneng',
    'Pekon Pariaman', 'Pekon Padang Ratu'
  ],
  'Kecamatan Bulok': [
    'Pekon Sukamaju', 'Pekon Pematang Nebak', 'Pekon Napal', 'Pekon Sinar Petir',
    'Pekon Banjar Masin'
  ],
  'Lintas Wilayah / Seluruh Daerah Tanggamus': [
    'Seluruh Pekon se-Kabupaten Tanggamus', 'Kawasan Agropolitan Ulu Belu & Gisting',
    'Kawasan Pesisir Teluk Semaka', 'Kawasan Hutan Lindung & Hulu DAS Sekampung'
  ]
};

export const INITIAL_MISI_RPJMD: MisiRPJMDItem[] = [
  {
    id: 'sdm_kesehatan',
    nomor: 'Misi 1',
    judul: 'Peningkatan Kualitas SDM & Kesehatan Universal',
    fokus: 'Pendidikan inklusif, penurunan stunting terintegrasi, jaminan kesehatan semesta (UHC), dan link-and-match vokasi kerja.',
    sasaranPokok: [
      'Peningkatan Indeks Pembangunan Manusia (IPM) dan akses pendidikan berkualitas',
      'Penurunan angka prevalensi stunting hingga di bawah 10%',
      'Cakupan kepesertaan JKN/BPJS Universal Health Coverage (UHC) 100%'
    ],
    indikatorKinerjaUtama: [
      'Indeks Pembangunan Manusia (IPM)',
      'Angka Harapan Hidup (AHH)',
      'Rata-rata Lama Sekolah (RLS)'
    ],
    opdPengampuUtama: 'Dinas Pendidikan & Kebudayaan, Dinas Kesehatan, Bapperida',
    warnaTema: 'blue',
    urutan: 1,
    statusAktif: true
  },
  {
    id: 'ekonomi_umkm',
    nomor: 'Misi 2',
    judul: 'Transformasi Ekonomi Kerakyatan & Hilirisasi UMKM',
    fokus: 'Pemberdayaan klaster UMKM digital, akses permodalan tanpa agunan, ekonomi kreatif, dan revitalisasi pasar tradisional.',
    sasaranPokok: [
      'Penguatan daya saing produk perkebunan kopi robusta, lada hitam & perikanan tangkap',
      'Digitalisasi dan fasilitasi legalitas izin NIB serta sertifikasi halal gratis bagi pelaku mikro',
      'Revitalisasi sarana pasar pekon dan penguatan kelembagaan koperasi produsen'
    ],
    indikatorKinerjaUtama: [
      'Laju Pertumbuhan Ekonomi Daerah',
      'Tingkat Pengangguran Terbuka (TPT)',
      'Kontribusi PDRB Sektor Pertanian & UMKM'
    ],
    opdPengampuUtama: 'Diskoperindag, Dinas Pertanian & Ketahanan Pangan, Dinas Perikanan',
    warnaTema: 'amber',
    urutan: 2,
    statusAktif: true
  },
  {
    id: 'infrastruktur_hijau',
    nomor: 'Misi 3',
    judul: 'Infrastruktur Berkelanjutan & Ketahanan Lingkungan',
    fokus: 'Konektivitas jalan mantap antardesa, mitigasi bencana hidrometeorologi, pengelolaan sampah sirkular, dan transisi energi bersih.',
    sasaranPokok: [
      'Peningkatan kemantapan jalan lingkar pekon dan akses sentra produksi agropolitan',
      'Mitigasi banjir pesisir Semaka dan pencegahan longsor lereng Gunung Tanggamus',
      'Penyediaan sanitasi komunal dan perluasan jaringan SPAM air minum perdesaan'
    ],
    indikatorKinerjaUtama: [
      'Persentase Kemantapan Jalan Kabupaten',
      'Indeks Kualitas Lingkungan Hidup (IKLH)',
      'Cakupan Akses Sanitasi & Air Minum Layak'
    ],
    opdPengampuUtama: 'Dinas PUPR, Dinas Lingkungan Hidup, BPBD Tanggamus',
    warnaTema: 'emerald',
    urutan: 3,
    statusAktif: true
  },
  {
    id: 'tata_kelola_digital',
    nomor: 'Misi 4',
    judul: 'Tata Kelola Pemerintahan Akuntabel & Digitalisasi',
    fokus: 'Keterbukaan informasi publik, satu data daerah terintegrasi, pencegahan korupsi, dan reformasi birokrasi berorientasi dampak.',
    sasaranPokok: [
      'Penyelenggaraan SPBE terpadu dan interoperabilitas Satu Data Tanggamus',
      'Penguatan akuntabilitas kinerja SAKIP bernilai A dan maturitas SPIP level 3',
      'Digitalisasi administrasi kependudukan dan perizinan terintegrasi jemput bola'
    ],
    indikatorKinerjaUtama: [
      'Indeks SPBE Kabupaten Tanggamus',
      'Nilai SAKIP & Reformasi Birokrasi (RB)',
      'Indeks Kepuasan Masyarakat (IKM)'
    ],
    opdPengampuUtama: 'Diskominfo, Inspektorat, Bagian Organisasi Setdakab, Bapperida',
    warnaTema: 'purple',
    urutan: 4,
    statusAktif: true
  },
  {
    id: 'sosial_budaya',
    nomor: 'Misi 5',
    judul: 'Ketahanan Sosial, Inklusi Rentan & Pelestarian Budaya',
    fokus: 'Perlindungan lansia dan penyandang disabilitas, perlindungan anak & perempuan, revitalisasi cagar budaya daerah, dan kohesi sosial.',
    sasaranPokok: [
      'Penanggulangan kemiskinan ekstrem melalui bansos adaptif dan jaring pengaman sosial',
      'Penyediaan fasilitas ramah disabilitas, ruang ramah anak, dan pencegahan kekerasan perempuan',
      'Pemajuan kebudayaan Lampung Saibatin, cagar megalitik Batu Bedil, dan kearifan lokal'
    ],
    indikatorKinerjaUtama: [
      'Tingkat Kemiskinan Makro',
      'Indeks Pembangunan Gender (IPG)',
      'Indeks Pembangunan Kebudayaan (IPK)'
    ],
    opdPengampuUtama: 'Dinas Sosial, Dinas PMD, Dinas Pariwisata & Kebudayaan',
    warnaTema: 'rose',
    urutan: 5,
    statusAktif: true
  }
];

export const MISI_LABELS: Record<string, { nomor: string; judul: string; fokus: string }> = {
  sdm_kesehatan: {
    nomor: 'Misi 1',
    judul: 'Peningkatan Kualitas SDM & Kesehatan Universal',
    fokus: 'Pendidikan inklusif, penurunan stunting terintegrasi, jaminan kesehatan semesta (UHC), dan link-and-match vokasi kerja.'
  },
  ekonomi_umkm: {
    nomor: 'Misi 2',
    judul: 'Transformasi Ekonomi Kerakyatan & Hilirisasi UMKM',
    fokus: 'Pemberdayaan klaster UMKM digital, akses permodalan tanpa agunan, ekonomi kreatif, dan revitalisasi pasar tradisional.'
  },
  infrastruktur_hijau: {
    nomor: 'Misi 3',
    judul: 'Infrastruktur Berkelanjutan & Ketahanan Lingkungan',
    fokus: 'Konektivitas jalan mantap antardesa, mitigasi bencana hidrometeorologi, pengelolaan sampah sirkular, dan transisi energi bersih.'
  },
  tata_kelola_digital: {
    nomor: 'Misi 4',
    judul: 'Tata Kelola Pemerintahan Akuntabel & Digitalisasi',
    fokus: 'Keterbukaan informasi publik, satu data daerah terintegrasi, pencegahan korupsi, dan reformasi birokrasi berorientasi dampak.'
  },
  sosial_budaya: {
    nomor: 'Misi 5',
    judul: 'Ketahanan Sosial, Inklusi Rentan & Pelestarian Budaya',
    fokus: 'Perlindungan lansia dan penyandang disabilitas, perlindungan anak & perempuan, revitalisasi cagar budaya daerah, dan kohesi sosial.'
  }
};

export const INITIAL_ASPIRASI: AspirasiPublik[] = [];

export const KEMITRAAN_CSR_DATA: KemitraanCSR[] = [];

export const RISET_AKADEMISI_DATA: RisetAkademisi[] = [];

export const INISIATIF_OMS_DATA: InisiatifOMS[] = [];

export const BAB_RPJMD_DATA: BabRPJMD[] = [
  {
    nomorBab: 'Bab I',
    judulBab: 'Pendahuluan & Gambaran Umum Kondisi Daerah',
    fokusBahasan: 'Analisis demografi, geografi, capaian RPJMD periode sebelumnya, isu strategis regional, dan proyeksi tantangan 2025-2029.',
    halamanTerkait: 'Halaman 1 - 84',
    totalMasukan: 148,
    catatanKritis: [
      {
        id: 'CK-01',
        nama: 'Dr. Irfan Santoso',
        institusi: 'Pusat Studi Demografi Universitas',
        tipe: 'akademisi',
        pasalBagian: 'Sub-Bab 1.4: Bonus Demografi & Produktivitas Usia Muda',
        komentar: 'Data proyeksi usia produktif perlu mencerminkan fenomena NEET (Not in Education, Employment, or Training) yang mencapai 18,2% agar program penanggulangan tidak bias kelompok kelas menengah saja.',
        tanggal: '26 Maret 2026'
      },
      {
        id: 'CK-02',
        nama: 'Agus Salim',
        institusi: 'Forum Warga Pantura',
        tipe: 'masyarakat',
        pasalBagian: 'Sub-Bab 1.6: Analisis Kerentanan Abrasi & Bencana Pesisir',
        komentar: 'Belum terpotret data penurunan muka tanah (land subsidence) tahunan yang menyebabkan rob permanen di 3 desa kami. Harap dimasukkan sebagai isu genting.',
        tanggal: '25 Maret 2026'
      }
    ]
  },
  {
    nomorBab: 'Bab II',
    judulBab: 'Visi, Misi, dan Tujuan Pembangunan Daerah',
    fokusBahasan: 'Formulasi visi jangka menengah daerah, elaborasi 5 misi strategis pentahelix, indikator tujuan makro, dan keterkaitan dengan RPJPN 2045.',
    halamanTerkait: 'Halaman 85 - 142',
    totalMasukan: 215,
    catatanKritis: [
      {
        id: 'CK-03',
        nama: 'Dewi Lestari, S.Sos.',
        institusi: 'Jaringan Perempuan Penggerak Pesisir',
        tipe: 'oms',
        pasalBagian: 'Misi 5: Ketahanan Sosial & Kesetaraan Gender',
        komentar: 'Harus ada komitmen eksplisit indikator Indeks Pembangunan Gender (IPG) minimal 92,0 dan persentase kepemimpinan perempuan dalam musrenbang desa di atas 30%.',
        tanggal: '24 Maret 2026'
      }
    ]
  },
  {
    nomorBab: 'Bab III',
    judulBab: 'Strategi, Arah Kebijakan, dan Program Prioritas',
    fokusBahasan: 'Rincian 24 program unggulan kepala daerah, matriks integrasi OPD, skema kolaborasi lintas aktor, dan lokus kewilayahan.',
    halamanTerkait: 'Halaman 143 - 290',
    totalMasukan: 382,
    catatanKritis: [
      {
        id: 'CK-04',
        nama: 'Bambang Widjanarko',
        institusi: 'Asosiasi Logistik & Rantai Pasok',
        tipe: 'swasta',
        pasalBagian: 'Program Prioritas 7: Revitalisasi Jalur Logistik Industri',
        komentar: 'Perlu jaminan ketepatan waktu perbaikan jalan kelas III menuju sentra industri kecil agar biaya pemeliharaan armada truk tidak membengkak.',
        tanggal: '27 Maret 2026'
      }
    ]
  },
  {
    nomorBab: 'Bab IV',
    judulBab: 'Kerangka Pendanaan Pembangunan & Indikator Kinerja Utama (IKU)',
    fokusBahasan: 'Proyeksi kapasitas riil fiskal daerah, skema creative financing (KPBU, obligasi daerah, zakat produktif, CSR), serta target numerik IKU 2025-2029.',
    halamanTerkait: 'Halaman 291 - 368',
    totalMasukan: 167,
    catatanKritis: [
      {
        id: 'CK-05',
        nama: 'Dr. Faisal Basri Jr.',
        institusi: 'Institut Riset Kebijakan Publik',
        tipe: 'akademisi',
        pasalBagian: 'Tabel 4.3: Proyeksi Penerimaan Bukan Pajak & KPBU',
        komentar: 'Asumsi pertumbuhan investasi swasta 7,5% terlalu optimis tanpa reformasi simplifikasi perizinan PBG/SLF. Sebaiknya gunakan proyeksi konservatif 5,2%.',
        tanggal: '28 Maret 2026'
      }
    ]
  }
];

export const KONSULTASI_AGENDA_DATA: KonsultasiAgenda[] = [
  {
    id: 'AGD-01',
    judulSidang: 'Musrenbang Tematik Kelompok Rentan, Disabilitas, Anak & Lansia',
    tipeAgenda: 'Musrenbang Tematik',
    pemangkuUtama: 'Organisasi Masyarakat Sipil, Komunitas Difabel, Forum Anak',
    tanggalWaktu: 'Kamis, 02 April 2026 · Pukul 09.00 - 14.30 WIB',
    tempat: 'Ruang Rapat Utama Bapperida Lt. 3 & Ruang Hybrid Zoom',
    tautanDaring: 'https://bapperida.daerah.go.id/live-musrenbang-rentan',
    statusPendaftaran: 'buka',
    kapasitas: '150 Kursi Fisik · 500 Peserta Virtual',
    topikKunci: ['Aksesibilitas Fasilitas Publik', 'Perlindungan Jaminan Sosial Anak Terlantar', 'Layanan Posyandu Lansia Holistik']
  },
  {
    id: 'AGD-02',
    judulSidang: 'Rembuk Kemitraan Dunia Usaha: Optimalisasi CSR untuk Pengentasan Kemiskinan',
    tipeAgenda: 'FGD Multipihak',
    pemangkuUtama: 'Kadin, APINDO, BUMD, Perbankan, BUMN Regional',
    tanggalWaktu: 'Senin, 06 April 2026 · Pukul 13.00 - 17.00 WIB',
    tempat: 'Grand Ballroom Hotel Majapahit & Siaran Live Streaming',
    tautanDaring: 'https://bapperida.daerah.go.id/csr-investment-forum',
    statusPendaftaran: 'buka',
    kapasitas: '200 Perwakilan Korporasi',
    topikKunci: ['Peta Peluang Investasi Hijau', 'Matchmaking Program TJSLP Desa Dampingan', 'Skema KPBU Fasilitas Air Bersih']
  },
  {
    id: 'AGD-03',
    judulSidang: 'Sidang Pleno Terbuka Konsultasi Publik Rancangan Awal RPJMD 2025-2029',
    tipeAgenda: 'Konsultasi Publik Terbuka',
    pemangkuUtama: 'Seluruh Elemen Masyarakat, DPRD, Rektorat Kampus, Media Massa',
    tanggalWaktu: 'Rabu, 15 April 2026 · Pukul 08.30 - 16.00 WIB',
    tempat: 'Gedung Sasana Praja Pemda & Saluran YouTube Pemerintah Daerah',
    tautanDaring: 'https://youtube.com/@pemda-resmi/live',
    statusPendaftaran: 'segera',
    kapasitas: '600 Delegasi Sidang',
    topikKunci: ['Paparan Visi-Misi Kepala Daerah Terpilih', 'Uji Publik Target IKU Makro', 'Penandatanganan Berita Acara Kesepakatan Multipihak']
  }
];

export const INITIAL_PRIORITAS_DATA = [
  { id: 'sdm', label: 'Menguatkan Kualitas Manusia Melalui Pendidikan dan Kesehatan', bobot: 25, konsensusWarga: 26.4 },
  { id: 'ekonomi', label: 'Meningkatkan Pertumbuhan Ekonomi Daerah', bobot: 20, konsensusWarga: 19.5 },
  { id: 'infrastruktur', label: 'Pemerataan Infrastruktur yang Berkeadilan', bobot: 25, konsensusWarga: 16.2 },
  { id: 'tata_kelola', label: 'Peningkatan Reformasi Birokrasi', bobot: 10, konsensusWarga: 6.8 },
  { id: 'lingkungan', label: 'Pengelolaan Sampah & Sabuk Hijau Tangguh Bencana', bobot: 20, konsensusWarga: 9.3 },
];

export const INITIAL_USERS: UserAccount[] = [
  {
    id: 'USR-001',
    name: 'Tim Bidang PME (Bapperida)',
    email: 'bidangpme@gmail.com',
    role: 'bapperida_admin',
    agency: 'Bapperida Litbang Daerah - Bidang PME',
    nip: '19840315 200801 1 003',
    jabatan: 'Kepala Bidang Pengendalian & Evaluasi',
    noHp: '0812-3456-7890',
    statusAktif: true,
    lastLogin: 'Aktif saat ini',
    createdAt: '15 Januari 2026'
  },
  {
    id: 'USR-002',
    name: 'Dra. Endang Sulistyowati, M.M.',
    email: 'verifikator.opd@daerah.go.id',
    role: 'opd_verifikator',
    agency: 'Dinas Koperasi, Perindustrian dan Perdagangan',
    nip: '19790512 200501 2 006',
    jabatan: 'Kepala Bidang Pemberdayaan UMKM',
    noHp: '0813-9876-5432',
    statusAktif: true,
    lastLogin: 'Kemarin, 14.20 WIB',
    createdAt: '20 Januari 2026'
  },
  {
    id: 'USR-003',
    name: 'Ir. Bambang Triharto, M.T.',
    email: 'bambang.pupr@daerah.go.id',
    role: 'opd_verifikator',
    agency: 'Dinas Pekerjaan Umum, Penataan Ruang & Kawasan Permukiman',
    nip: '19760820 200212 1 004',
    jabatan: 'Kepala Bidang Bina Marga & Drainase',
    noHp: '0811-2233-4455',
    statusAktif: true,
    lastLogin: '2 hari lalu',
    createdAt: '22 Januari 2026'
  },
  {
    id: 'USR-004',
    name: 'Dr. Retno Wulandari',
    email: 'retno.akademisi@kampus.ac.id',
    role: 'pemangku_kepentingan',
    agency: 'Pusat Studi Pembangunan LPPM Universitas',
    nip: 'NIDN: 0015088201',
    jabatan: 'Koordinator Riset Terapan LPPM',
    noHp: '0852-6789-0123',
    statusAktif: true,
    lastLogin: '3 hari lalu',
    createdAt: '01 Februari 2026'
  }
];

export const INITIAL_KEHADIRAN_SIDANG: KonfirmasiKehadiranSidang[] = [
  {
    id: 'RSVP-01',
    agendaId: 'AGD-01',
    judulSidang: 'Musrenbang Tematik Kelompok Rentan, Disabilitas, Anak & Lansia',
    namaLengkap: 'Rizki Amanda, S.Kom.',
    instansi: 'Forum Inklusi & Aksesibilitas Indonesia (FIAI)',
    unsurPentahelix: 'oms',
    jabatan: 'Koordinator Advokasi Aksesibilitas',
    email: 'rizki.fiai@organisasi.or.id',
    nomorKontak: '0813-1122-3344',
    bentukKehadiran: 'luring',
    statusVerifikasi: 'terkonfirmasi',
    pokokPikiran: 'Menyerahkan draf naskah rekomendasi aksesibilitas trotoar sentra kota dan implementasi 2% kuota disabilitas di BUMD.',
    waktuDaftar: '29 Maret 2026, 10.15 WIB'
  },
  {
    id: 'RSVP-02',
    agendaId: 'AGD-01',
    judulSidang: 'Musrenbang Tematik Kelompok Rentan, Disabilitas, Anak & Lansia',
    namaLengkap: 'Siti Aminah, M.Pd.',
    instansi: 'Lembaga Perlindungan Hak Anak & Lansia Peduli',
    unsurPentahelix: 'masyarakat',
    jabatan: 'Fasilitator Forum Anak Daerah',
    email: 'siti.aminah@forumanak.id',
    nomorKontak: '0812-9988-7766',
    bentukKehadiran: 'daring',
    statusVerifikasi: 'terkonfirmasi',
    pokokPikiran: 'Perluasan cakupan beasiswa anak yatim/piatu dan integrasi data posyandu lansia dengan program permakanan dinsos.',
    waktuDaftar: '29 Maret 2026, 14.30 WIB'
  },
  {
    id: 'RSVP-03',
    agendaId: 'AGD-02',
    judulSidang: 'Rembuk Kemitraan Dunia Usaha: Optimalisasi CSR untuk Pengentasan Kemiskinan',
    namaLengkap: 'Hendrawan Kusuma, M.B.A.',
    instansi: 'KADIN Komite Tetap CSR & Keberlanjutan',
    unsurPentahelix: 'swasta',
    jabatan: 'Wakil Ketua Bidang Investasi Sosial',
    email: 'hendrawan@kadin-daerah.org',
    nomorKontak: '0811-9876-5432',
    bentukKehadiran: 'luring',
    statusVerifikasi: 'terkonfirmasi',
    pokokPikiran: 'Memaparkan komitmen konsorsium 12 korporasi untuk program elektrifikasi PLTS microgrid di 8 desa tertinggal.',
    waktuDaftar: '28 Maret 2026, 16.45 WIB'
  },
  {
    id: 'RSVP-04',
    agendaId: 'AGD-03',
    judulSidang: 'Sidang Pleno Terbuka Konsultasi Publik Rancangan Awal RPJMD 2025-2029',
    namaLengkap: 'Prof. Dr. Ir. Suyitno, M.Sc.',
    instansi: 'Konsorsium Perguruan Tinggi Negeri Regional',
    unsurPentahelix: 'akademisi',
    jabatan: 'Guru Besar Perencanaan Wilayah & Kota',
    email: 'suyitno.pwk@univ-negeri.ac.id',
    nomorKontak: '0818-0234-5678',
    bentukKehadiran: 'luring',
    statusVerifikasi: 'terkonfirmasi',
    pokokPikiran: 'Penyampaian telaah kritis pembiayaan inovatif (Municipal Bond) dan validasi proyeksi pertumbuhan fiskal 5 tahun.',
    waktuDaftar: '27 Maret 2026, 11.20 WIB'
  },
  {
    id: 'RSVP-05',
    agendaId: 'AGD-01',
    judulSidang: 'Musrenbang Tematik Kelompok Rentan, Disabilitas, Anak & Lansia',
    namaLengkap: 'Agus Salim',
    instansi: 'Forum Warga Pantura Pesisir',
    unsurPentahelix: 'masyarakat',
    jabatan: 'Ketua Paguyuban Nelayan & Warga Tanggul',
    email: 'agus.pantura@warga.id',
    nomorKontak: '0853-4455-6677',
    bentukKehadiran: 'daring',
    statusVerifikasi: 'menunggu',
    pokokPikiran: 'Usulan shelter evakuasi rob ramah lansia dan kelompok rentan di pesisir utara.',
    waktuDaftar: '30 Maret 2026, 08.10 WIB'
  }
];

export const INITIAL_OPD_TANGGAMUS: UnitKerjaOPD[] = [
  {
    id: 'OPD-01',
    kodeOpd: '1.01.01.01',
    namaOpd: 'Badan Perencanaan Pembangunan, Riset dan Inovasi Daerah (BAPPERIDA)',
    singkatan: 'BAPPERIDA',
    kategori: 'badan',
    kepalaNama: 'H. Hendra Wijaya Mega, S.T., M.T., M.M.',
    kepalaNip: '19740512 199903 1 004',
    kepalaJabatan: 'Kepala Bapperida Kab. Tanggamus',
    alamatKantor: 'Kompleks Perkantoran Pemkab Tanggamus, Jl. Jenderal Sudirman No. 1, Kota Agung',
    emailKontak: 'bapperida@tanggamus.go.id',
    teleponKontak: '(0722) 21012',
    fokusMisiRpjmd: ['sdm_kesehatan', 'ekonomi_umkm', 'infrastruktur_hijau', 'tata_kelola_digital', 'sosial_budaya'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 48
  },
  {
    id: 'OPD-02',
    kodeOpd: '1.03.01.01',
    namaOpd: 'Dinas Pekerjaan Umum dan Perumahan Rakyat (PUPR)',
    singkatan: 'DINAS PUPR',
    kategori: 'dinas',
    kepalaNama: 'Ir. Riski Septiansyah, S.T., M.T.',
    kepalaNip: '19760920 200212 1 005',
    kepalaJabatan: 'Kepala Dinas PUPR Kab. Tanggamus',
    alamatKantor: 'Jl. Merdeka No. 45, Kuripan, Kota Agung, Kab. Tanggamus',
    emailKontak: 'pupr@tanggamus.go.id',
    teleponKontak: '(0722) 21155',
    fokusMisiRpjmd: ['infrastruktur_hijau'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 34
  },
  {
    id: 'OPD-03',
    kodeOpd: '1.02.01.01',
    namaOpd: 'Dinas Kesehatan Kabupaten Tanggamus',
    singkatan: 'DINKES',
    kategori: 'dinas',
    kepalaNama: 'Taufik Hidayat, S.K.M., M.Kes.',
    kepalaNip: '19710315 199503 1 002',
    kepalaJabatan: 'Kepala Dinas Kesehatan',
    alamatKantor: 'Jl. Samudera No. 12, Pasar Madang, Kota Agung',
    emailKontak: 'dinkes@tanggamus.go.id',
    teleponKontak: '(0722) 21088',
    fokusMisiRpjmd: ['sdm_kesehatan'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 29
  },
  {
    id: 'OPD-04',
    kodeOpd: '1.01.02.01',
    namaOpd: 'Dinas Pendidikan dan Kebudayaan',
    singkatan: 'DISDIKBUD',
    kategori: 'dinas',
    kepalaNama: 'Yadi Mulyadi, S.Pd., M.M.',
    kepalaNip: '19690814 199412 1 003',
    kepalaJabatan: 'Kepala Dinas Pendidikan & Kebudayaan',
    alamatKantor: 'Jl. Pemda Raya Blok B, Kompleks Islamic Center, Kota Agung',
    emailKontak: 'disdik@tanggamus.go.id',
    teleponKontak: '(0722) 21320',
    fokusMisiRpjmd: ['sdm_kesehatan', 'sosial_budaya'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 26
  },
  {
    id: 'OPD-05',
    kodeOpd: '2.01.01.01',
    namaOpd: 'Dinas Koperasi, UKM, Perindustrian dan Perdagangan',
    singkatan: 'DISKOPERINDAG',
    kategori: 'dinas',
    kepalaNama: 'Hj. Retno Damayanti, S.E., M.M.',
    kepalaNip: '19731102 199803 2 006',
    kepalaJabatan: 'Kepala Diskoperindag',
    alamatKantor: 'Jl. Ir. H. Juanda No. 88, Terbangi, Kota Agung',
    emailKontak: 'diskoperindag@tanggamus.go.id',
    teleponKontak: '(0722) 21411',
    fokusMisiRpjmd: ['ekonomi_umkm'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 22
  },
  {
    id: 'OPD-06',
    kodeOpd: '2.02.01.01',
    namaOpd: 'Dinas Pertanian dan Ketahanan Pangan',
    singkatan: 'DISTAN-KP',
    kategori: 'dinas',
    kepalaNama: 'Ir. Catur Agus Dewanto, M.Si.',
    kepalaNip: '19700428 199603 1 001',
    kepalaJabatan: 'Kepala Dinas Pertanian & KP',
    alamatKantor: 'Jl. Raya Gisting Blok 18, Gisting Bawah, Tanggamus',
    emailKontak: 'pertanian@tanggamus.go.id',
    teleponKontak: '(0722) 32104',
    fokusMisiRpjmd: ['ekonomi_umkm', 'infrastruktur_hijau'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 19
  },
  {
    id: 'OPD-07',
    kodeOpd: '2.03.01.01',
    namaOpd: 'Dinas Perikanan dan Kelautan',
    singkatan: 'DISKANLUT',
    kategori: 'dinas',
    kepalaNama: 'Darmansyah, S.Pi., M.Si.',
    kepalaNip: '19750119 200003 1 003',
    kepalaJabatan: 'Kepala Dinas Perikanan',
    alamatKantor: 'Kawasan Pelabuhan Perikanan Kota Agung, Tanggamus',
    emailKontak: 'perikanan@tanggamus.go.id',
    teleponKontak: '(0722) 21900',
    fokusMisiRpjmd: ['ekonomi_umkm'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 15
  },
  {
    id: 'OPD-08',
    kodeOpd: '1.04.01.01',
    namaOpd: 'Dinas Lingkungan Hidup Kabupaten Tanggamus',
    singkatan: 'DLH',
    kategori: 'dinas',
    kepalaNama: 'Kemal Pasha, S.H., M.H.',
    kepalaNip: '19721208 199903 1 002',
    kepalaJabatan: 'Kepala Dinas Lingkungan Hidup',
    alamatKantor: 'Jl. Samudera No. 24, Kuripan, Kota Agung',
    emailKontak: 'dlh@tanggamus.go.id',
    teleponKontak: '(0722) 21244',
    fokusMisiRpjmd: ['infrastruktur_hijau'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 21
  },
  {
    id: 'OPD-09',
    kodeOpd: '1.08.01.01',
    namaOpd: 'Dinas Komunikasi, Informatika, Statistik dan Persandian',
    singkatan: 'DISKOMINFO',
    kategori: 'dinas',
    kepalaNama: 'Suprayitno, S.Kom., M.T.I.',
    kepalaNip: '19790214 200501 1 008',
    kepalaJabatan: 'Kepala Diskominfo Kab. Tanggamus',
    alamatKantor: 'Gedung Otonom Lt. 2, Kompleks Pemkab Tanggamus, Kota Agung',
    emailKontak: 'diskominfo@tanggamus.go.id',
    teleponKontak: '(0722) 21777',
    fokusMisiRpjmd: ['tata_kelola_digital'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 18
  },
  {
    id: 'OPD-10',
    kodeOpd: '1.06.01.01',
    namaOpd: 'Dinas Sosial Kabupaten Tanggamus',
    singkatan: 'DINSOS',
    kategori: 'dinas',
    kepalaNama: 'Drs. Zulfadli, M.M.',
    kepalaNip: '19680710 199303 1 005',
    kepalaJabatan: 'Kepala Dinas Sosial',
    alamatKantor: 'Jl. Melati No. 05, Kota Agung Timur, Tanggamus',
    emailKontak: 'dinsos@tanggamus.go.id',
    teleponKontak: '(0722) 21633',
    fokusMisiRpjmd: ['sosial_budaya'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 17
  },
  {
    id: 'OPD-11',
    kodeOpd: '1.05.01.01',
    namaOpd: 'Badan Penanggulangan Bencana Daerah (BPBD)',
    singkatan: 'BPBD',
    kategori: 'badan',
    kepalaNama: 'Ir. Ediyan M. Toha, M.Si.',
    kepalaNip: '19701005 199703 1 004',
    kepalaJabatan: 'Kepala Pelaksana BPBD Kab. Tanggamus',
    alamatKantor: 'Jl. Lintas Barat KM 112, Kampung Baru, Kota Agung Timur',
    emailKontak: 'bpbd@tanggamus.go.id',
    teleponKontak: '(0722) 21999',
    fokusMisiRpjmd: ['infrastruktur_hijau'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 16
  },
  {
    id: 'OPD-12',
    kodeOpd: '4.01.01.01',
    namaOpd: 'Sekretariat Daerah Kabupaten Tanggamus',
    singkatan: 'SETDAKAB',
    kategori: 'sekretariat',
    kepalaNama: 'Drs. Suaidi, M.M.',
    kepalaNip: '19660412 199203 1 007',
    kepalaJabatan: 'Sekretaris Daerah Kab. Tanggamus',
    alamatKantor: 'Kantor Bupati Tanggamus, Jl. Jend. Sudirman No. 1, Kota Agung',
    emailKontak: 'setdakab@tanggamus.go.id',
    teleponKontak: '(0722) 21001',
    fokusMisiRpjmd: ['tata_kelola_digital', 'sdm_kesehatan', 'ekonomi_umkm', 'infrastruktur_hijau', 'sosial_budaya'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 25
  },
  {
    id: 'OPD-13',
    kodeOpd: '4.02.01.01',
    namaOpd: 'Inspektorat Daerah Kabupaten Tanggamus',
    singkatan: 'INSPEKTORAT',
    kategori: 'inspektorat',
    kepalaNama: 'Ernalia, S.Sos., M.Si.',
    kepalaNip: '19710817 199603 2 002',
    kepalaJabatan: 'Inspektur Daerah Kab. Tanggamus',
    alamatKantor: 'Kompleks Pemkab Tanggamus, Kota Agung',
    emailKontak: 'inspektorat@tanggamus.go.id',
    teleponKontak: '(0722) 21008',
    fokusMisiRpjmd: ['tata_kelola_digital'],
    statusAktif: true,
    jumlahAspirasiDitinjau: 12
  }
];



