import React, { useState } from 'react';
import { AspirasiPublik, StakeholderType, MisiRPJMD } from '../types';
import { KECAMATAN_TANGGAMUS } from '../data/mockData';

interface FormAspirasiModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (newAspirasi: AspirasiPublik) => void;
}

export const FormAspirasiModal: React.FC<FormAspirasiModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [tipePemangku, setTipePemangku] = useState<StakeholderType>('masyarakat');
  const [misiId, setMisiId] = useState<MisiRPJMD>('sdm_kesehatan');
  const [nama, setNama] = useState('');
  const [institusi, setInstitusi] = useState('');
  const [kecamatan, setKecamatan] = useState<string>(KECAMATAN_TANGGAMUS[0]);
  const [judul, setJudul] = useState('');
  const [ringkasan, setRingkasan] = useState('');
  const [deskripsi, setDeskripsi] = useState('');
  const [anggaranEstimasi, setAnggaranEstimasi] = useState('');
  const [bentukKolaborasi, setBentukKolaborasi] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nama.trim() || !judul.trim() || !ringkasan.trim() || !deskripsi.trim()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const generatedId = `ASP-2026-${Math.floor(100 + Math.random() * 900)}`;
      const newEntry: AspirasiPublik = {
        id: generatedId,
        judul,
        ringkasan,
        deskripsiLengkap: deskripsi,
        pengusulNama: nama,
        pengusulInstitusi: institusi || undefined,
        tipePemangku,
        misiId,
        kecamatan,
        tanggalDiajukan: new Date().toLocaleDateString('id-ID', {
          day: 'numeric',
          month: 'long',
          year: 'numeric'
        }),
        dukunganSuara: 1,
        hasVoted: true,
        status: 'ditelaah',
        anggaranEstimasi: anggaranEstimasi || 'Dalam Kajian Teknis Pemda',
        bentukKolaborasiDitawarkan: bentukKolaborasi || 'Bersedia hadir dalam musrenbang kecamatan/tematik lanjutan.',
        tanggapanOPD: [
          {
            id: `TGP-${Date.now()}`,
            opdNama: 'Bapperida - Sekretariat Tim Penyusun RPJMD',
            pejabatNama: 'Tim Verifikasi Masukan Publik',
            pejabatJabatan: 'Verifikator Pokja Perencanaan',
            tanggal: new Date().toLocaleDateString('id-ID', {
              day: 'numeric',
              month: 'long',
              year: 'numeric'
            }),
            isiTanggapan: 'Aspirasi telah diterima dan masuk ke dalam buku kendali telaah Renja Perangkat Daerah terkait.',
            statusPenetapan: 'ditelaah'
          }
        ],
        komentarPublik: []
      };

      onSubmit(newEntry);
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 400);
  };

  const handleResetAndClose = () => {
    setIsSuccess(false);
    setNama('');
    setInstitusi('');
    setJudul('');
    setRingkasan('');
    setDeskripsi('');
    setAnggaranEstimasi('');
    setBentukKolaborasi('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-stone-200 overflow-hidden my-6">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-emerald-900 font-semibold uppercase tracking-wider">
              Formulir Partisipasi Resmi
            </span>
            <h3 className="text-lg font-serif font-bold text-stone-900">
              Sampaikan Aspirasi & Usulan Program RPJMD
            </h3>
          </div>
          <button
            onClick={handleResetAndClose}
            className="p-1 rounded-md text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto text-xl font-bold">
              ✓
            </div>
            <h4 className="text-xl font-serif font-bold text-stone-900">
              Aspirasi Berhasil Didaftarkan!
            </h4>
            <p className="text-sm text-stone-600 max-w-md mx-auto leading-relaxed">
              Usulan Anda telah tercatat dalam sistem kendali Bapperida dan langsung terbit di Ruang Rembuk Publik agar dapat didukung oleh warga lain.
            </p>
            <div className="pt-4">
              <button
                onClick={handleResetAndClose}
                className="px-6 py-2.5 bg-emerald-900 hover:bg-emerald-950 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-sm"
              >
                Lihat di Daftar Aspirasi
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
            
            {/* Tipe Pemangku & Misi Target */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Kategori Pemangku Kepentingan *
                </label>
                <select
                  value={tipePemangku}
                  onChange={(e) => setTipePemangku(e.target.value as StakeholderType)}
                  className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
                >
                  <option value="masyarakat">Masyarakat / Komunitas Warga</option>
                  <option value="swasta">Dunia Usaha / Asosiasi Bisnis</option>
                  <option value="akademisi">Akademisi / Peneliti Kampus</option>
                  <option value="oms">Organisasi Masyarakat Sipil (OMS)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Misi RPJMD yang Dituju *
                </label>
                <select
                  value={misiId}
                  onChange={(e) => setMisiId(e.target.value as MisiRPJMD)}
                  className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
                >
                  <option value="sdm_kesehatan">Misi 1: SDM Unggul & Kesehatan Universal</option>
                  <option value="ekonomi_umkm">Misi 2: Transformasi Ekonomi & UMKM</option>
                  <option value="infrastruktur_hijau">Misi 3: Infrastruktur & Lingkungan Hidup</option>
                  <option value="tata_kelola_digital">Misi 4: Tata Kelola & Digitalisasi</option>
                  <option value="sosial_budaya">Misi 5: Ketahanan Sosial & Inklusi</option>
                </select>
              </div>
            </div>

            {/* Nama, Institusi & Kecamatan */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Nama Lengkap Pengusul *
                </label>
                <input
                  type="text"
                  required
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  placeholder="Contoh: Budi Santoso"
                  className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Institusi / Asosiasi / RT/RW
                </label>
                <input
                  type="text"
                  value={institusi}
                  onChange={(e) => setInstitusi(e.target.value)}
                  placeholder="Contoh: RW 04 Kel. Sawojajar / Kadin"
                  className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Wilayah / Kecamatan  *
                </label>
                <select
                  value={kecamatan}
                  onChange={(e) => setKecamatan(e.target.value)}
                  className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
                >
                  {KECAMATAN_TANGGAMUS.map((kec) => (
                    <option key={kec} value={kec}>
                      {kec}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Judul & Ringkasan */}
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Judul Program / Usulan *
              </label>
              <input
                type="text"
                required
                value={judul}
                onChange={(e) => setJudul(e.target.value)}
                placeholder="Contoh: Pengadaan Fasilitas Pengolahan Sampah Organik Terpadu Tingkat RW"
                className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Ringkasan Usulan (1-2 kalimat) *
              </label>
              <input
                type="text"
                required
                value={ringkasan}
                onChange={(e) => setRingkasan(e.target.value)}
                placeholder="Jelaskan secara singkat esensi solusi dan target penerima manfaat..."
                className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
              />
            </div>

            {/* Deskripsi Lengkap */}
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Uraian Latar Belakang Masalah & Solusi Nyata *
              </label>
              <textarea
                required
                rows={4}
                value={deskripsi}
                onChange={(e) => setDeskripsi(e.target.value)}
                placeholder="Jelaskan secara rinci permasalahan yang dihadapi, mengapa perlu masuk ke RPJMD, serta bagaimana program ini harus dieksekusi oleh Pemda..."
                className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800 leading-relaxed"
              />
            </div>

            {/* Kolaborasi & Estimasi Anggaran */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Estimasi Anggaran / Skema Pembiayaan
                </label>
                <input
                  type="text"
                  value={anggaranEstimasi}
                  onChange={(e) => setAnggaranEstimasi(e.target.value)}
                  placeholder="Misal: Rp 450 Juta / Swadaya / CSR / APBD Murni"
                  className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Bentuk Sinergi / Kolaborasi yang Ditawarkan
                </label>
                <input
                  type="text"
                  value={bentukKolaborasi}
                  onChange={(e) => setBentukKolaborasi(e.target.value)}
                  placeholder="Misal: Penyediaan tenaga relawan / Hibah lahan / Pendampingan lab"
                  className="w-full bg-white border border-stone-300 rounded px-3 py-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>
            </div>

            {/* Form Footer Action */}
            <div className="pt-4 border-t border-stone-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={handleResetAndClose}
                className="px-4 py-2 text-xs font-semibold text-stone-700 hover:text-stone-900 bg-white border border-stone-300 rounded transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 text-xs font-semibold text-white bg-emerald-900 hover:bg-emerald-950 rounded transition-colors cursor-pointer shadow-xs"
              >
                {isSubmitting ? 'Memproses...' : 'Kirim Aspirasi ke Bapperida'}
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
